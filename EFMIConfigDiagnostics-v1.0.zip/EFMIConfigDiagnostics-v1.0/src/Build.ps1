﻿$ErrorActionPreference = 'Stop'
$outputDir = Split-Path -Parent $PSScriptRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll (('/win32manifest:') + (Join-Path $PSScriptRoot 'app.manifest')) (('/out:') + (Join-Path $outputDir 'EFMIConfigDiagnostics.exe')) (Join-Path $PSScriptRoot 'Collector.cs')
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
