﻿using System;
using System.IO;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
[assembly:AssemblyTitle("终末地模组兼容修复")]
[assembly:AssemblyDescription("EFMI 材质 / 深度通道兼容修复工具")]
[assembly:AssemblyVersion("1.2.0.0")]
namespace EFMIRepair {
static class Program {
 [DllImport("user32.dll")]static extern bool SetProcessDPIAware();
 [STAThread]static int Main(string[] args) {
  if(args.Length>0)return CommandLine(args);
  try{SetProcessDPIAware();Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new RepairForm());return 0;}catch(Exception e){MessageBox.Show(e.Message,"无法启动",MessageBoxButtons.OK,MessageBoxIcon.Error);return 3;}
 }
 static int CommandLine(string[] args) {
  string output=null;for(int i=0;i<args.Length-1;i++)if(args[i]=="--report")output=args[i+1];
  try{if(args.Length<2)throw new ArgumentException("用法：--scan / --apply / --restore EFMI路径 [--report 报告路径]");string report;int code=0;
   if(args[0]=="--restore")report=Engine.Restore(args[1]);else {var plan=Engine.Scan(args[1]);report=plan.Report();if(plan.Blocked)code=2;else {if(plan.Skipped>0)code=4;if(args[0]=="--apply")report+="\r\n\r\n"+Engine.Apply(plan);else if(args[0]!="--scan")throw new ArgumentException("未知命令");}}
   if(output!=null)File.WriteAllText(output,report,new System.Text.UTF8Encoding(false));Console.WriteLine(report);return code;
  }catch(Exception e){if(output!=null)File.WriteAllText(output,"错误："+e.Message,new System.Text.UTF8Encoding(false));Console.Error.WriteLine(e);return 3;}
 }
}
class RepairForm:Form {
 TextBox folder=new TextBox(),log=new TextBox();Button browse=new Button(),scan=new Button(),fix=new Button(),restore=new Button(),export=new Button();Label status=new Label();
 public RepairForm(){
  Text="终末地模组兼容修复 v1.2";ClientSize=new Size(850,670);MinimumSize=new Size(740,600);StartPosition=FormStartPosition.CenterScreen;Font=new Font("Microsoft YaHei UI",10);BackColor=Color.FromArgb(245,247,249);
  var title=new Label{Text="终末地 · 模组批量修复",AutoSize=true,Font=new Font(Font.FontFamily,19,FontStyle.Bold),Location=new Point(24,20)};Controls.Add(title);
  var intro=new Label{Text="扫描整个 Mods 目录，修复可识别的贴图槽位与深度通道兼容问题。",AutoSize=true,Location=new Point(27,66)};Controls.Add(intro);
  var hint=new Label{Text="选择 EFMI、Mods 或 XXMI Launcher 文件夹：",AutoSize=true,Location=new Point(27,104)};Controls.Add(hint);
  folder.SetBounds(28,133,665,29);folder.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;Controls.Add(folder);
  browse.Text="选择文件夹";browse.SetBounds(705,131,118,33);browse.Anchor=AnchorStyles.Top|AnchorStyles.Right;browse.Click+=(s,e)=>{using(var d=new FolderBrowserDialog{Description="选择 EFMI、Mods 或 XXMI Launcher 文件夹",ShowNewFolderButton=false})if(d.ShowDialog(this)==DialogResult.OK)folder.Text=d.SelectedPath;};Controls.Add(browse);
  scan.Text="仅扫描";scan.SetBounds(28,180,120,40);scan.Click+=async(s,e)=>await Run("scan");Controls.Add(scan);
  fix.Text="一键备份并修复";fix.SetBounds(161,180,190,40);fix.BackColor=Color.FromArgb(25,98,147);fix.ForeColor=Color.White;fix.FlatStyle=FlatStyle.Flat;fix.Click+=async(s,e)=>await Run("apply");Controls.Add(fix);
  restore.Text="还原上次修复";restore.SetBounds(364,180,160,40);restore.Click+=async(s,e)=>await Run("restore");Controls.Add(restore);
  export.Text="导出报告";export.SetBounds(537,180,125,40);export.Click+=(s,e)=>{using(var d=new SaveFileDialog{Filter="文本报告|*.txt",FileName="EFMI修复报告.txt"})if(d.ShowDialog(this)==DialogResult.OK)try{File.WriteAllText(d.FileName,log.Text,new System.Text.UTF8Encoding(false));}catch(Exception ex){MessageBox.Show(this,ex.Message,"报告未保存",MessageBoxButtons.OK,MessageBoxIcon.Error);}};Controls.Add(export);
  log.SetBounds(28,239,795,340);log.Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Both;log.WordWrap=false;log.BackColor=Color.White;log.Text="使用方法：\r\n1. 选择 EFMI 文件夹。\r\n2. 点击“一键备份并修复”；也可先点击“仅扫描”查看改动。\r\n3. 完成后进入游戏按 F10，核对异常角色。\r\n\r\nv1.2：按资源与特效接口接入统一的当前游戏规则，不限制版本号，\r\n也不依赖旧版正则的写法；保留原版按键、特效和清理逻辑。\r\n继续支持固定贴图槽位、深度同步与盐濑纱良版陈千语适配。\r\n\r\n无法提供所需资源或特效数据的版本会明确提示，不强行修改。\r\n跨版本分支已做离线验证，仍需进入游戏确认效果。\r\n本工具修复显示兼容问题，不包含卡顿或底层 DLL 优化。\r\n\r\n修复前会自动保存逐文件备份；修复后可还原。";Controls.Add(log);
  status.SetBounds(28,592,795,24);status.Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;status.Text="就绪 · 无需安装 Python · 无联网功能";Controls.Add(status);
  var footer=new Label{Text="只修改匹配规则的 INI；保留启动设置、游戏文件、模型和贴图。",AutoSize=false,Location=new Point(28,625),Size=new Size(795,25),Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right,ForeColor=Color.DimGray};Controls.Add(footer);
 }
 async Task Run(string mode){if(String.IsNullOrWhiteSpace(folder.Text)){browse.PerformClick();if(String.IsNullOrWhiteSpace(folder.Text))return;}string selected=folder.Text;foreach(Control c in new Control[]{browse,scan,fix,restore,folder,export})c.Enabled=false;status.Text=mode=="restore"?"正在校验并还原…":"正在扫描与校验…";
  try{string completion="";string result=await Task.Run(()=>{if(mode=="restore"){completion="还原完成 · 请查看报告";return Engine.Restore(selected);}var p=Engine.Scan(selected);completion=p.Blocked?"未执行 · 请先处理报告中的冲突":p.Skipped>0?"含未适配项 · 请查看报告，跳过项目未强制修改":mode=="scan"?"扫描完成 · 尚未写入任何修改":"完成 · 游戏内按 F10 载入变更";if(mode=="scan"||p.Blocked)return p.Report();return p.Report()+"\r\n\r\n"+Engine.Apply(p);});log.Text=result;status.Text=completion;}
  catch(Exception ex){log.AppendText("\r\n\r\n未完成："+ex.Message);status.Text="未完成 · 请查看原因，未匹配的文件不会强制修改";}
  finally{foreach(Control c in new Control[]{browse,scan,fix,restore,folder,export})c.Enabled=true;}
 }
}
}
