﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Xml.Serialization;

namespace EFMIRepair {
public class Change { public string Relative, Reason, BeforeHash; public byte[] Before, After; }
public class Plan {
 public string Root; public List<Change> Changes = new List<Change>();
 public List<string> Messages = new List<string>(); public int Scanned, Covered, Skipped; public bool Blocked;
 public string Report() { return "EFMI 模组兼容修复 v1.2\r\n目标："+Root+"\r\n扫描 "+Scanned+" 个 INI；待修改 "+Changes.Count+" 个文件；共用规则覆盖 "+Covered+" 个配置；跳过 "+Skipped+" 个配置。\r\n\r\n"+String.Join("\r\n",Messages)+"\r\n\r\n"+String.Join("\r\n",Changes.Select(c=>"[待修复] "+c.Relative+"\r\n  "+c.Reason)); }
}
public class Entry { public string Relative, BeforeHash, AfterHash; public bool Created; }
public class BackupManifest { public string Root, State, Version; public List<Entry> Files=new List<Entry>(); }
class Ini {
 public byte[] Raw; public string Text; public Encoding Encoding; public byte[] Bom; public string Eol;
 string[] originalLines,originalEols;bool mixedEols;
 public Ini(byte[] raw) {
  Raw=raw; Bom=new byte[0]; int offset=0;
  if(raw.Length>=3 && raw[0]==239 && raw[1]==187 && raw[2]==191) { Encoding=new UTF8Encoding(false,true); offset=3; }
  else if(raw.Length>=2 && raw[0]==255 && raw[1]==254) { Encoding=new UnicodeEncoding(false,false,true); offset=2; }
  else if(raw.Length>=2 && raw[0]==254 && raw[1]==255) { Encoding=new UnicodeEncoding(true,false,true); offset=2; }
  else { Encoding=new UTF8Encoding(false,true); try { Encoding.GetString(raw); } catch(DecoderFallbackException) { Encoding=System.Text.Encoding.GetEncoding(54936,EncoderFallback.ExceptionFallback,DecoderFallback.ExceptionFallback); } }
  Bom=raw.Take(offset).ToArray(); string text=Encoding.GetString(raw,offset,raw.Length-offset);
  Eol=text.Contains("\r\r\n")?"\r\r\n":text.Contains("\r\n")?"\r\n":text.Contains("\n")?"\n":text.Contains("\r")?"\r":"\n";
  var endings=Regex.Matches(text,@"\r\r\n|\r\n|\r|\n").Cast<Match>().Select(m=>m.Value).ToArray();
  originalEols=endings;mixedEols=endings.Distinct().Count()>1;
  Text=Regex.Replace(text,@"\r\r\n|\r\n|\r|\n","\n");originalLines=Text.Split('\n');
  if(!Bom.Concat(Encoding.GetBytes(text)).SequenceEqual(raw)) throw new InvalidDataException("配置编码无法无损保留");
 }
 // Hirschberg line alignment uses linear memory. Unchanged lines retain their own
 // original terminators even when a mod mixes CRLF, LF, CR or CRCRLF.
 static int[] Scores(string[] a,int ai,int an,string[] b,int bi,int bn,bool reverse) {
  var row=new int[bn+1];
  for(int i=0;i<an;i++){int diagonal=0;for(int j=1;j<=bn;j++){int previous=row[j];if(a[ai+(reverse?an-1-i:i)]==b[bi+(reverse?bn-j:j-1)])row[j]=diagonal+1;else row[j]=Math.Max(row[j],row[j-1]);diagonal=previous;}}
  return row;
 }
 static void Align(string[] a,int ai,int an,string[] b,int bi,int bn,int[] map) {
  while(an>0&&bn>0&&a[ai]==b[bi]){map[bi]=ai;ai++;bi++;an--;bn--;}
  while(an>0&&bn>0&&a[ai+an-1]==b[bi+bn-1]){map[bi+bn-1]=ai+an-1;an--;bn--;}
  if(an==0||bn==0)return;
  if(an==1){for(int j=0;j<bn;j++)if(a[ai]==b[bi+j]){map[bi+j]=ai;break;}return;}
  int half=an/2,split=0,best=-1;int[] left=Scores(a,ai,half,b,bi,bn,false),right=Scores(a,ai+half,an-half,b,bi,bn,true);
  for(int j=0;j<=bn;j++)if(left[j]+right[bn-j]>best){best=left[j]+right[bn-j];split=j;}
  Align(a,ai,half,b,bi,split,map);Align(a,ai+half,an-half,b,bi+split,bn-split,map);
 }
 public byte[] Encode(string text) {
  if(text==Text)return Raw;
  if(!mixedEols)return Bom.Concat(Encoding.GetBytes(Eol=="\n"?text:text.Replace("\n",Eol))).ToArray();
  string[] lines=text.Split('\n');var map=Enumerable.Repeat(-1,lines.Length).ToArray();Align(originalLines,0,originalLines.Length,lines,0,lines.Length,map);var result=new StringBuilder();
  for(int i=0;i<lines.Length;i++){result.Append(lines[i]);if(i<lines.Length-1)result.Append(map[i]>=0&&map[i]<originalEols.Length?originalEols[map[i]]:Eol);}
  return Bom.Concat(Encoding.GetBytes(result.ToString())).ToArray();
 }
}
public static class Engine {
 public const string Marker="; EFMI Mod Repair v1.0 - 2026-10 compatibility";
 const string ShiftMarker="; Endfield 2026-10 material layout; old/prepass bindings retained below.";
 const string SharedFile="EFMICompat202610.ini";
 static Regex Sections=new Regex(@"(?ms)^\[([^\]\r\n]+)\][^\n]*\n(.*?)(?=^\[|\z)");
 static Regex Slots=new Regex(@"(?<![\w])ps-t(1\d|2[0-4])(?!\d)",RegexOptions.IgnoreCase);
 static Regex Calls=new Regex(@"(?im)^[ \t]*run[ \t]*=[ \t]*CommandList\\RabbitFx\\SetTextures[ \t]*$");
 public static string Hash(byte[] data) { using(var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(data)).Replace("-","").ToLowerInvariant(); }
 static bool Has(string text,string value) { return text.IndexOf(value,StringComparison.OrdinalIgnoreCase)>=0; }
 static string Shift(string text) { return String.Join("\n",text.Split('\n').Select(l=>l.TrimStart().StartsWith(";")?l:Slots.Replace(l,m=>"ps-t"+(Int32.Parse(m.Groups[1].Value)+1)))); }
 static int Balance(string s) { int n=0; foreach(string l in s.Split('\n')) { string t=l.Trim(); if(Regex.IsMatch(t,@"^if\s",RegexOptions.IgnoreCase))n++; else if(t.Equals("endif",StringComparison.OrdinalIgnoreCase))n--; if(n<0)return -1; } return n; }
 public static string RootOf(string input) {
  string path=Path.GetFullPath(input.Trim().Trim('"')).TrimEnd(Path.DirectorySeparatorChar);
  if(String.Equals(Path.GetFileName(path),"Mods",StringComparison.OrdinalIgnoreCase))path=Directory.GetParent(path).FullName;
  if(!File.Exists(Path.Combine(path,"d3dx.ini")) && Directory.Exists(Path.Combine(path,"EFMI")))path=Path.Combine(path,"EFMI");
  if(!File.Exists(Path.Combine(path,"d3dx.ini")) || !Directory.Exists(Path.Combine(path,"Mods")) || !File.Exists(Path.Combine(path,"Core","EFMI","API.ini")))throw new InvalidDataException("请选择有效的 EFMI 文件夹，或其 Mods 文件夹 / XXMI Launcher 文件夹。");
  RejectLink(path); RejectLink(Path.Combine(path,"Mods"));return path;
 }
 static void RejectLink(string path) { if((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("为避免修改到其他目录，请选择实际文件夹，不使用目录链接："+path); }
 static bool Disabled(string name) { return name.StartsWith("disabled",StringComparison.OrdinalIgnoreCase)||name.StartsWith(".")||name.StartsWith("backup",StringComparison.OrdinalIgnoreCase)||name.StartsWith("备份")||name.StartsWith("_ModRepairBackups",StringComparison.OrdinalIgnoreCase); }
 static void Walk(string directory,List<string> result,List<string> messages) {
  foreach(string p in Directory.GetFiles(directory,"*.ini")) { if(Disabled(Path.GetFileName(p)))continue; if((File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0) { messages.Add("[跳过链接] "+p);continue; } result.Add(p); }
  foreach(string d in Directory.GetDirectories(directory)) { if(Disabled(Path.GetFileName(d)))continue; if((File.GetAttributes(d)&FileAttributes.ReparsePoint)!=0){messages.Add("[跳过链接] "+d);continue;} Walk(d,result,messages); }
 }
 static string Within(string root,string relative) {
  if(String.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative))throw new InvalidDataException("备份包含非法路径");
  string prefix=Path.GetFullPath(root).TrimEnd('\\')+"\\";string full=Path.GetFullPath(Path.Combine(root,relative));
  if(!full.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("路径超出目标目录");
  for(string p=full; p!=null && p.StartsWith(prefix,StringComparison.OrdinalIgnoreCase);p=Path.GetDirectoryName(p))if(File.Exists(p)||Directory.Exists(p))RejectLink(p);
  return full;
 }
 static string Section(string text,string name) { foreach(Match m in Sections.Matches(text))if(m.Groups[1].Value.Equals(name,StringComparison.OrdinalIgnoreCase))return m.Groups[2].Value;throw new InvalidDataException("缺少配置节："+name); }
 static string SlotPatch(string text,out int count) {
  int n=0; if(text.Contains(ShiftMarker)||text.Contains("; EFMIRepair fixed-slot adaptation applied")){count=0;return text;}
  string result=Sections.Replace(text,m=>{
   string name=m.Groups[1].Value,body=m.Groups[2].Value;
   string active=String.Join("\n",body.Split('\n').Where(l=>!l.TrimStart().StartsWith(";")));
   if(!Slots.IsMatch(active)||name.Equals("CommandListSlotEnter",StringComparison.OrdinalIgnoreCase)||name.Equals("CommandListSlotExit",StringComparison.OrdinalIgnoreCase))return m.Value;
   if(name.StartsWith("CommandList",StringComparison.OrdinalIgnoreCase)) {n++;return "["+name+"]\n"+ShiftMarker+"\nif ps == 1718.4\n"+Shift(body)+"\nelse\n"+body+"\nendif\n\n";}
   if(!name.StartsWith("TextureOverride",StringComparison.OrdinalIgnoreCase))return m.Value;
   var lines=new List<string>();foreach(string line in body.Split('\n')) {if(!line.TrimStart().StartsWith(";") && Regex.IsMatch(line,@"^[ \t]*ps-t(?:1\d|2[0-4])[ \t]*=",RegexOptions.IgnoreCase)){n++;lines.Add("if ps == 1718.4\n"+Shift(line)+"\nelse\n"+line+"\nendif");}else lines.Add(line);}return "["+name+"]\n"+String.Join("\n",lines);
  });count=n;return n>0?"; EFMIRepair fixed-slot adaptation applied\n"+result:result;
 }
 static bool IsChen(string text) { return new[]{"[Key$Tattoo]","[Resource_Texture821]","[Resource_Texture6b]","[CustomShader_RecordBones_C5]","ResourceID_CrossIB_C0_EFFECT"}.All(x=>Has(text,x)); }
 static string DepthPatch(string text,out bool changed) {
  changed=false; if(Has(text,"[CommandListChenSetTextures]")||Has(text,"[CommandListEFMIRepairSetTextures]"))return text;
  if(!Calls.IsMatch(text))return text;
  string s=Calls.Replace(text,"run = CommandListEFMIRepairSetTextures");
  if(IsChen(text)) {
   string old="Resource\\RabbitFx\\LightMap = ref Resource_Texture72\nendif\nrun = CommandListEFMIRepairSetTextures";
   int count=Regex.Matches(s,Regex.Escape(old)).Count;if(count!=2 && count!=4)throw new InvalidDataException("陈千语材质选择结构与已验证版本不符");
   s=s.Replace(old,"Resource\\RabbitFx\\LightMap = ref Resource_Texture72\nendif\nResource\\RabbitFx\\NormalMap = ref Resource_Texture6\nrun = CommandListEFMIRepairSetTextures");
   s=s.Replace("Resource\\RabbitFx\\Diffuse = ref Resource_Texture17\nrun = CommandListEFMIRepairSetTextures","Resource\\RabbitFx\\Diffuse = ref Resource_Texture17\nResource\\RabbitFx\\NormalMap = ref Resource_Texture6b\nrun = CommandListEFMIRepairSetTextures");
   string body=Section(s,"CommandList_Draw_Component5"), replacement=body;string needle="endif\nrun = CommandListEFMIRepairSetTextures";int index=body.IndexOf(needle,StringComparison.Ordinal);if(index<0)throw new InvalidDataException("陈千语皮肤材质结构不匹配");
   replacement=body.Substring(0,index)+body.Substring(index).Replace(needle,"endif\nResource\\RabbitFx\\NormalMap = ref Resource_Texture6b\nrun = CommandListEFMIRepairSetTextures");s=s.Replace(body,replacement);
  }
  changed=true;return s+"\n"+Marker+@"
[CommandListEFMIRepairSetTextures]
if (ps == 1718.2 || ps-cb1->Size / 16 == 4096 || (ps-cb2->Size / 16 == 4096 && ps-cb0->Size / 16 <= 16)) && DRAW_TYPE == 4
    if Resource\RabbitFx\Diffuse !== null
        ps-t0 = ref Resource\RabbitFx\Diffuse
    endif
    if Resource\RabbitFx\NormalMap !== null
        ps-t1 = ref Resource\RabbitFx\NormalMap
    endif
    if Resource\RabbitFx\DiscardMap !== null
        ps-t2 = ref Resource\RabbitFx\DiscardMap
    endif
    Resource\RabbitFx\Diffuse = null
    Resource\RabbitFx\LightMap = null
    Resource\RabbitFx\NormalMap = null
    Resource\RabbitFx\DiscardMap = null
    Resource\RabbitFx\RainMap = null
endif
run = CommandList\RabbitFx\SetTextures
";
 }
 static string Classifier() {return Marker+@"
namespace = EFMICompat202610
[ShaderRegexMaterialLayout]
shader_model = ps_4_0 ps_5_0
filter_index = 1718.4
[ShaderRegexMaterialLayout.Pattern]
dcl_constantbuffer\hCB0\[45\].+\ndcl_constantbuffer\hCB1\[141\].+\ndcl_constantbuffer\hCB2\[40\d{2}\].+\ndcl_constantbuffer\hCB3\[2054\].+\ndcl_constantbuffer\hCB4\[4\].+\n(?:dcl.*\n)*?dcl_output\ho0\.xyzw\ndcl_output\ho1\.xyzw\ndcl_temps.*\n
"; }
 public static Plan Scan(string input) {
  var plan=new Plan();plan.Root=RootOf(input);string mods=Path.Combine(plan.Root,"Mods");var files=new List<string>();Walk(mods,files,plan.Messages);files.Sort(StringComparer.OrdinalIgnoreCase);plan.Scanned=files.Count;
  var loaded=new Dictionary<string,Ini>();foreach(string path in files)try{loaded[path]=new Ini(File.ReadAllBytes(path));}catch(Exception e){plan.Skipped++;plan.Messages.Add("[无法读取] "+path+"："+e.Message);}
  var rabbits=loaded.Where(k=>Regex.IsMatch(k.Value.Text,@"(?im)^[ \t]*namespace[ \t]*=[ \t]*RabbitFX[ \t]*(?:;[^\n]*)?$")).ToList();bool mainReady=false;
  if(rabbits.Count>1){plan.Blocked=true;plan.Messages.Add("[需先处理] 发现多个启用的 RabbitFX，存在冲突，未生成修改。请保留一个版本后重扫。");return plan;}
  if(rabbits.Count==1)foreach(var pair in loaded){if(pair.Key==rabbits[0].Key)continue;if(Regex.IsMatch(pair.Value.Text,@"(?im)^filter_index[ \t]*=[ \t]*1718\.4[ \t]*(?:;[^\n]*)?$") && !(Path.GetFileName(pair.Key).Equals(SharedFile,StringComparison.OrdinalIgnoreCase)&&pair.Value.Text.Contains(Marker))){plan.Blocked=true;plan.Messages.Add("[规则冲突] 1718.4 已被其他配置使用，未生成修改："+pair.Key.Substring(mods.Length+1));return plan;}}
  if(rabbits.Count==1){var pair=rabbits[0];try{string description;string n=RabbitAdapter.Adapt(pair.Value.Text,out description);Add(plan,mods,pair.Key,pair.Value,n,"RabbitFX 新版颜色 / 光照 / 法线识别；"+description);mainReady=true;plan.Messages.Add("[共用材质] "+description+"。已接入当前游戏兼容规则，新增版本仍需游戏内核对。");}catch(Exception e){plan.Messages.Add("[结构未识别] "+e.Message+"。已跳过 RabbitFX 及依赖它的贴图/深度修改，未标记为修复成功。");plan.Skipped++;}}
  else {
   string shared=Path.Combine(mods,SharedFile);if(File.Exists(shared)){if(!loaded.ContainsKey(shared)||!loaded[shared].Text.Contains(Marker)){plan.Blocked=true;plan.Messages.Add("[文件冲突] "+SharedFile+" 已存在且不属于本工具");return plan;}mainReady=true;}
   else {bool needed=loaded.Values.Any(i=>(Has(i.Text,"\\EFMIv1\\OverrideTextures")||Regex.IsMatch(i.Text,@"(?im)^global(?:[ \t]+persist)?[ \t]+\$object_guid[ \t]*=")) && Slots.IsMatch(i.Text));if(needed){foreach(var v in loaded.Values)if(Regex.IsMatch(v.Text,@"(?im)^filter_index[ \t]*=[ \t]*1718\.4[ \t]*$")){plan.Blocked=true;plan.Messages.Add("[规则冲突] 1718.4 已被其他补丁使用");return plan;}plan.Changes.Add(new Change{Relative=SharedFile,Before=null,BeforeHash=null,After=new UTF8Encoding(false).GetBytes(Classifier().Replace("\n","\r\n")),Reason="新版主材质通道识别（此目录未安装 RabbitFX）"});mainReady=true;}}
  }
  foreach(var pair in loaded) {
   string path=pair.Key;Ini ini=pair.Value;string t=ini.Text;
   if(rabbits.Any(k=>k.Key==path)||Has(t,"namespace = EFMICompat202610"))continue;
   bool efmi=Has(t,"\\EFMIv1\\OverrideTextures")||Regex.IsMatch(t,@"(?im)^global(?:[ \t]+persist)?[ \t]+\$object_guid[ \t]*=");
   bool rabbitCalls=Calls.IsMatch(t);if(!efmi && !rabbitCalls){continue;}
   if(rabbits.Count==1 && !mainReady){plan.Skipped++;plan.Messages.Add("[依赖未适配] "+path.Substring(mods.Length+1)+"：先处理 RabbitFX 结构差异，本配置保持原样");continue;}
   try {string n=t;int shifts=0;bool depth=false;if(mainReady)n=SlotPatch(n,out shifts);if(rabbits.Count==1 && mainReady)n=DepthPatch(n,out depth);if(Balance(n)!=Balance(t))throw new InvalidDataException("条件块校验失败");
    Add(plan,mods,path,ini,n,String.Join("；",new[]{shifts>0?"固定贴图槽位适配 "+shifts+" 处":null,depth?(IsChen(t)?"陈千语：深度贴图与法线同步":"RabbitFX：深度通道贴图同步"):null}.Where(x=>x!=null)));
    if(mainReady && rabbitCalls)plan.Covered++;
    if(n==t){if(Has(t,ShiftMarker)||Has(t,Marker)||Has(t,"[CommandListChenSetTextures]"))plan.Messages.Add("[已适配] "+path.Substring(mods.Length+1));else {plan.Skipped++;plan.Messages.Add("[未匹配] "+path.Substring(mods.Length+1)+"：未找到本次可迁移规则；若此模组仍异常，需另行适配");}}
   }catch(Exception e){plan.Skipped++;plan.Messages.Add("[跳过] "+path.Substring(mods.Length+1)+"："+e.Message);}
  }
  plan.Messages.Add("处理范围：整个 Mods 目录。修复已识别的新版本材质与深度通道问题；模型、骨骼、资源哈希变化需单独适配。");
  plan.Messages.Add("不会修改 XXMI 启动设置、游戏文件、DDS 贴图或模型资源。已停用的文件夹、备份和目录链接不会扫描。");return plan;
 }
 static void Add(Plan plan,string mods,string path,Ini ini,string text,string reason) { if(text==ini.Text)return;byte[] after=ini.Encode(text);plan.Changes.Add(new Change{Relative=path.Substring(mods.Length+1),Before=ini.Raw,BeforeHash=Hash(ini.Raw),After=after,Reason=reason}); }
 static void Atomic(string path,byte[] data) {string temp=path+".efmirepair-"+Guid.NewGuid().ToString("N")+".tmp";try{File.WriteAllBytes(temp,data);if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);}finally{if(File.Exists(temp))File.Delete(temp);} }
 static void SaveManifest(string dir,BackupManifest manifest) {using(var fs=File.Create(Path.Combine(dir,"manifest.xml")))new XmlSerializer(typeof(BackupManifest)).Serialize(fs,manifest);}
 public static string Apply(Plan plan) {
  if(plan.Blocked)throw new InvalidOperationException("请先处理扫描报告中的冲突");if(plan.Changes.Count==0)return plan.Skipped>0?"未执行修复：存在未适配的配置，请查看上方原因。文件未改动。":"没有需要修改的文件。";
  string root=RootOf(plan.Root),mods=Path.Combine(root,"Mods");foreach(Change c in plan.Changes){string p=Within(mods,c.Relative);if(c.Before==null?File.Exists(p):!File.Exists(p)||Hash(File.ReadAllBytes(p))!=c.BeforeHash)throw new IOException("扫描后文件发生了变化，请重新扫描："+c.Relative);}
  string backupStore=Path.Combine(root,"_ModRepairBackups");if(Directory.Exists(backupStore))RejectLink(backupStore);
  string backup=Path.Combine(backupStore,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8));Directory.CreateDirectory(backup);RejectLink(Path.GetDirectoryName(backup));
  var m=new BackupManifest{Root=root,Version="1.2",State="prepared"};foreach(Change c in plan.Changes){m.Files.Add(new Entry{Relative=c.Relative,BeforeHash=c.BeforeHash,AfterHash=Hash(c.After),Created=c.Before==null});if(c.Before!=null){string dest=Within(Path.Combine(backup,"originals"),c.Relative);Directory.CreateDirectory(Path.GetDirectoryName(dest));File.WriteAllBytes(dest,c.Before);}}
  SaveManifest(backup,m);File.WriteAllText(Path.Combine(backup,"report.txt"),plan.Report(),new UTF8Encoding(false));
  var applied=new List<Change>();try{foreach(Change c in plan.Changes){string path=Within(mods,c.Relative);if(c.Before==null?File.Exists(path):Hash(File.ReadAllBytes(path))!=c.BeforeHash)throw new IOException("写入前文件已变化："+c.Relative);Atomic(path,c.After);applied.Add(c);if(Hash(File.ReadAllBytes(path))!=Hash(c.After))throw new IOException("写入校验失败："+c.Relative);}m.State="applied";SaveManifest(backup,m);}
  catch(Exception error){bool ok=true;foreach(Change c in applied.AsEnumerable().Reverse()){try{string path=Within(mods,c.Relative);if(Hash(File.ReadAllBytes(path))!=Hash(c.After))throw new IOException("已被其他程序修改");if(c.Before==null)File.Delete(path);else Atomic(path,c.Before);}catch{ok=false;}}m.State=ok?"rolled_back":"partial";SaveManifest(backup,m);throw new IOException("修复未完成，"+(ok?"本次写入已回滚。":"部分文件需从备份恢复。")+"\r\n备份："+backup+"\r\n"+error.Message,error);}
  return "修复完成："+plan.Changes.Count+" 个文件已写入并校验。\r\n备份："+backup+"\r\n进入游戏按 F10 重新加载；也可下次启动时自动载入。\r\n请核对异常角色。未匹配的模型或骨骼问题不会被标记为已修复。";
 }
 public static string Restore(string input) {
  string root=RootOf(input),store=Path.Combine(root,"_ModRepairBackups");if(!Directory.Exists(store))return "此目录没有本工具创建的备份。";RejectLink(store);string selected=null;BackupManifest m=null;
  foreach(string dir in Directory.GetDirectories(store).OrderByDescending(x=>x,StringComparer.OrdinalIgnoreCase)){RejectLink(dir);string f=Path.Combine(dir,"manifest.xml");if(!File.Exists(f))continue;RejectLink(f);using(var fs=File.OpenRead(f))m=(BackupManifest)new XmlSerializer(typeof(BackupManifest)).Deserialize(fs);if(m.State=="partial_restore")throw new IOException("上次还原存在未完成的回滚，请先检查备份："+dir);if(m.State=="applied"||m.State=="partial"){selected=dir;break;}}
  if(selected==null)return "没有尚未还原的修复记录。";
  if(!String.Equals(Path.GetFullPath(m.Root),root,StringComparison.OrdinalIgnoreCase))throw new IOException("备份属于另一个 EFMI 目录");string mods=Path.Combine(root,"Mods");
  foreach(Entry e in m.Files){string path=Within(mods,e.Relative);if(!File.Exists(path)||Hash(File.ReadAllBytes(path))!=e.AfterHash)throw new IOException("为保留后续修改，本次未还原。文件在修复后已变化："+e.Relative+"\r\n原始文件在："+selected);if(!e.Created){string src=Within(Path.Combine(selected,"originals"),e.Relative);if(!File.Exists(src)||Hash(File.ReadAllBytes(src))!=e.BeforeHash)throw new IOException("备份校验失败："+e.Relative);}}
  var repairedBytes=new Dictionary<string,byte[]>();foreach(Entry e in m.Files)repairedBytes[e.Relative]=File.ReadAllBytes(Within(mods,e.Relative));
  var restored=new List<Entry>();try{foreach(Entry e in m.Files){string path=Within(mods,e.Relative);if(Hash(File.ReadAllBytes(path))!=e.AfterHash)throw new IOException("还原前文件发生变化："+e.Relative);if(e.Created)File.Delete(path);else Atomic(path,File.ReadAllBytes(Within(Path.Combine(selected,"originals"),e.Relative)));restored.Add(e);}m.State="restored";SaveManifest(selected,m);}
  catch(Exception error){bool ok=true;foreach(Entry e in restored.AsEnumerable().Reverse()){try{string path=Within(mods,e.Relative);if(e.Created?File.Exists(path):!File.Exists(path)||Hash(File.ReadAllBytes(path))!=e.BeforeHash)throw new IOException("还原中的文件又被修改");Atomic(path,repairedBytes[e.Relative]);}catch{ok=false;}}m.State=ok?"applied":"partial_restore";SaveManifest(selected,m);throw new IOException("还原未完成，"+(ok?"此次还原已回滚。":"部分文件需人工检查。")+"\r\n备份："+selected+"\r\n"+error.Message,error);}
  return "已还原最近一次修复的 "+m.Files.Count+" 个文件。\r\n游戏内按 F10 载入。备份记录保留在："+selected;
 }
}
}



