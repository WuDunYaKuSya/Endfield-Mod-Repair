﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace EFMIRepair {
public class ProfileCatalog { public List<ModProfile> Profiles=new List<ModProfile>();public List<string> PreserveHashes=new List<string>();public List<string> StableRabbitHashes=new List<string>(); }
public class ModProfile { public string Id,Name,Anchor,Evidence,Mutex;public List<ProfileFile> Files=new List<ProfileFile>();public List<ProfileAsset> Assets=new List<ProfileAsset>(); }
public class ProfileFile { public string Relative,TargetHash;public List<RecipeVariant> Variants=new List<RecipeVariant>();public List<string> OptionalMissing=new List<string>();public List<string> OptionalUi=new List<string>(); }
public class ProfileAsset { public string Relative,Hash; }
public class RecipeVariant { public string SourceHash;public List<OutputPart> Parts=new List<OutputPart>(); }
public class OutputPart { public bool Copy;public int Index,Count;public string Text; }
static class ProfilePlanner {
 static string TextHash(string text){return Engine.Hash(new UTF8Encoding(false).GetBytes(text));}
 static ProfileCatalog Load(){using(var stream=typeof(ProfilePlanner).Assembly.GetManifestResourceStream("EFMIRepair.Profiles.xml")){if(stream==null)throw new InvalidDataException("程序缺少完整配置规则库，请完整解压或重新构建。");return (ProfileCatalog)new XmlSerializer(typeof(ProfileCatalog)).Deserialize(stream);}}
 static bool Accepts(ProfileFile file,string hash){return file.TargetHash==hash||file.Variants.Any(x=>x.SourceHash==hash);}
 static string Patch(ProfileFile file,Ini ini){string hash=TextHash(ini.Text);if(hash==file.TargetHash)return ini.Text;var recipe=file.Variants.SingleOrDefault(x=>x.SourceHash==hash);if(recipe==null)throw new InvalidDataException("配置与已验证输入不符");var lines=ini.Text.Split('\n');var output=new List<string>();foreach(OutputPart part in recipe.Parts){if(part.Copy){if(part.Index<0||part.Count<0||part.Index>lines.Length-part.Count)throw new InvalidDataException("内置规则的复制范围无效");output.AddRange(lines.Skip(part.Index).Take(part.Count));}else output.Add(part.Text??"");}string result=String.Join("\n",output);if(TextHash(result)!=file.TargetHash)throw new InvalidDataException("内置规则的输出校验失败");return result;}
 static bool Rabbit(string text){return Regex.IsMatch(text,@"(?im)^[ \t]*namespace[ \t]*=[ \t]*RabbitFX[ \t]*(?:;[^\n]*)?$");}
 static bool IsRabbitAux(string path,string rabbitPath,string text){string dir=Path.GetDirectoryName(rabbitPath).TrimEnd('\\')+"\\";return path.StartsWith(dir,StringComparison.OrdinalIgnoreCase)&&!Regex.IsMatch(text,@"(?im)^\[(?:TextureOverride|ShaderOverride|ShaderRegex|CustomShader)|\b(?:ps|vs)-t\d|\bdraw(?:indexed|instanced)?\s*=");}
 internal static void ValidateFile(string mods,string file,string text,IEnumerable<string> optionalMissing=null){
  var allowed=new HashSet<string>(optionalMissing??Enumerable.Empty<string>(),StringComparer.OrdinalIgnoreCase);
  var sections=Regex.Matches(text,@"(?ms)^\[([^\]\r\n]+)\][^\n]*\n(.*?)(?=^\[|\z)").Cast<Match>();
  foreach(Match section in sections){if(section.Groups[1].Value.StartsWith("ShaderRegex",StringComparison.OrdinalIgnoreCase))continue;int balance=0;foreach(string line in section.Groups[2].Value.Split('\n')){string trimmed=line.Trim();if(Regex.IsMatch(trimmed,@"^if\s",RegexOptions.IgnoreCase))balance++;else if(trimmed.Equals("endif",StringComparison.OrdinalIgnoreCase))balance--;if(balance<0)throw new InvalidDataException("条件块缺少起始语句："+section.Groups[1].Value);}if(balance!=0)throw new InvalidDataException("条件块不完整："+section.Groups[1].Value);}
  foreach(Match value in Regex.Matches(text,@"(?im)^[ \t]*filename[ \t]*=[ \t]*([^;\n]+)")){string relative=value.Groups[1].Value.Trim();if(Path.IsPathRooted(relative))throw new InvalidDataException("资源使用绝对路径，未自动迁移："+relative);string full=Path.GetFullPath(Path.Combine(Path.GetDirectoryName(file),relative));string prefix=mods.TrimEnd('\\')+"\\";if(!full.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("资源路径超出 Mods："+relative);string checkedPath=Engine.CheckedPath(mods,full.Substring(prefix.Length));if(!File.Exists(checkedPath)&&!allowed.Contains(full.Substring(prefix.Length)))throw new FileNotFoundException("缺少配套资源，未修改配置："+relative);}
 }
 internal static void Build(Plan plan,Dictionary<string,Ini> loaded,string mods){
  ProfileCatalog catalog=Load();var hashes=loaded.ToDictionary(x=>x.Key,x=>TextHash(x.Value.Text),StringComparer.OrdinalIgnoreCase);var consumed=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var visited=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var mutexes=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  var rabbits=loaded.Where(x=>Rabbit(x.Value.Text)).ToList();if(rabbits.Count==1){foreach(Match key in Regex.Matches(rabbits[0].Value.Text,@"(?ms)^\[(Key[^\]\n]*(?:Censor|Fade|Transparen)[^\]\n]*)\][^\n]*\n(.*?)(?=^\[|\z)",RegexOptions.IgnoreCase)){Match binding=Regex.Match(key.Groups[2].Value,@"(?im)^[ \t]*key[ \t]*=[ \t]*([^;\n]+)");if(binding.Success)plan.Messages.Add("[近景点阵检查] RabbitFX 自带渐隐/反虚化开关："+binding.Groups[1].Value.Trim()+"。若发际线、衣缘出现小黑点，请进游戏用此键核对；本工具保留当前开关状态，不把该现象当成重复偏移的理由。");}}if(rabbits.Count>1){plan.Blocked=true;plan.Messages.Add("[冲突] 多个 RabbitFX 同时启用，未生成任何修改。");return;}
  if(rabbits.Count==1&&loaded.Any(x=>x.Key!=rabbits[0].Key&&Regex.IsMatch(x.Value.Text,@"(?im)^filter_index\s*=\s*1718\.4\s*(?:;[^\n]*)?$"))){plan.Blocked=true;plan.Messages.Add("[共享通道冲突] 1718.4 被 RabbitFX 之外的配置占用，未生成修改。");return;}
  foreach(var pair in loaded.OrderBy(x=>x.Key,StringComparer.OrdinalIgnoreCase)){
   var matches=catalog.Profiles.Where(p=>p.Files.Any(f=>f.Relative==p.Anchor&&Accepts(f,hashes[pair.Key]))).ToList();if(matches.Count==0)continue;if(matches.Count!=1){plan.Blocked=true;plan.Messages.Add("[规则冲突] 一个配置同时命中多个规则，未写入。");plan.Changes.Clear();return;}
   ModProfile profile=matches[0];string group=Path.GetDirectoryName(pair.Key);string key=group+"|"+profile.Id;if(!visited.Add(key))continue;var paths=new Dictionary<string,string>();var additions=new List<Change>();var assets=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);var optional=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var missingUi=new HashSet<string>(StringComparer.OrdinalIgnoreCase);bool good=true;
   try{
    foreach(ProfileFile file in profile.Files){string path=file.Relative==profile.Anchor?pair.Key:Engine.CheckedPath(mods,Path.Combine(group,file.Relative).Substring(mods.TrimEnd('\\').Length+1));paths.Add(file.Relative,path);if(!loaded.ContainsKey(path)||!Accepts(file,hashes[path]))throw new InvalidDataException("配套配置缺失、已改动或是其他作者版本："+file.Relative);}
    string prefix=group.TrimEnd('\\')+"\\";var expected=new HashSet<string>(paths.Values,StringComparer.OrdinalIgnoreCase);if(loaded.Keys.Any(path=>path.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)&&!expected.Contains(path)))throw new InvalidDataException("同一模组目录里有规则库之外的启用 INI，需先核对，未做部分适配");
    foreach(ProfileFile file in profile.Files){foreach(string relative in file.OptionalMissing){string full=Path.GetFullPath(Path.Combine(Path.GetDirectoryName(paths[file.Relative]),relative));string prefixRoot=mods.TrimEnd('\\')+"\\";if(!full.StartsWith(prefixRoot,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("规则库中的既有缺失资源路径越界");optional.Add(full.Substring(prefixRoot.Length));}}
    // Only explicit, profile-specific UI resources audited against the exact
    // target may be absent. Never infer optionality from an image extension.
    foreach(ProfileFile file in profile.Files)foreach(string relative in file.OptionalUi){string full=Path.GetFullPath(Path.Combine(Path.GetDirectoryName(paths[file.Relative]),relative));string prefixRoot=mods.TrimEnd('\\')+"\\";if(!full.StartsWith(prefixRoot,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("界面资源路径越界");string local=full.Substring(prefixRoot.Length);if(!File.Exists(Engine.CheckedPath(mods,local)))missingUi.Add(local);}
    foreach(ProfileAsset asset in profile.Assets){string full=Path.GetFullPath(Path.Combine(group,asset.Relative));string prefixRoot=mods.TrimEnd('\\')+"\\";if(!full.StartsWith(prefixRoot,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("模型资源路径越界");string relative=full.Substring(prefixRoot.Length);string safe=Engine.CheckedPath(mods,relative);if(!File.Exists(safe)||Engine.Hash(File.ReadAllBytes(safe))!=asset.Hash)throw new InvalidDataException("模型或骨架着色器与已验证样本不同，未修改："+asset.Relative);assets.Add(relative,asset.Hash);}
    foreach(ProfileFile file in profile.Files){string path=paths[file.Relative];Ini ini=loaded[path];string target=Patch(file,ini);ValidateFile(mods,path,target,optional.Concat(missingUi));byte[] after=ini.Encode(target);if(!after.SequenceEqual(ini.Raw))additions.Add(new Change{Relative=path.Substring(mods.TrimEnd('\\').Length+1),Before=ini.Raw,BeforeHash=Engine.Hash(ini.Raw),After=after,Reason=profile.Name+"：完整配置指纹匹配；输出按参考目标校验"});}
   }catch(Exception error){good=false;plan.Messages.Add("[该组保持原样] "+profile.Name+"："+error.Message);}
   if(!good)continue;
   foreach(string resource in missingUi){plan.ApprovedMissing.Add(resource);plan.Messages.Add("[界面图片缺失，模型修复可继续] "+profile.Name+"："+resource+"；该引用已核对为作者菜单图片，角色模型与材质仍按规则校验。本工具不补图；菜单可能显示不完整，请从同版本作者原包补回此文件。此提示不代表界面已修复。");}
   if(!String.IsNullOrEmpty(profile.Mutex)){string other;if(mutexes.TryGetValue(profile.Mutex,out other)&&!String.Equals(other,group,StringComparison.OrdinalIgnoreCase)){plan.Blocked=true;plan.Changes.Clear();plan.Messages.Add("[互斥冲突] 同时启用了两套 "+profile.Mutex+"，请只保留一套。");return;}mutexes[profile.Mutex]=group;}
   foreach(string path in paths.Values)consumed.Add(path);foreach(var asset in assets)plan.AssetGuards[asset.Key]=asset.Value;foreach(string missing in optional)plan.ApprovedMissing.Add(missing);if(optional.Count>0)plan.Messages.Add("[既有资源说明] "+profile.Name+"：参考配置已有 "+optional.Count+" 项缺失资源声明；本工具不补图，不新增这类引用；涉及的原作者选项仍需游戏核对。");plan.Changes.AddRange(additions);plan.Covered+=profile.Files.Count;plan.Recognized++;
   plan.Messages.Add((additions.Count==0?"[参考配置一致，保持原样] ":"[已匹配专用规则] ")+profile.Name+"；参考样本记录（不代表本机游戏验证）："+profile.Evidence);
  }
  var missingAnchors=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  foreach(var pair in loaded.Where(x=>!consumed.Contains(x.Key)))foreach(ModProfile profile in catalog.Profiles)foreach(ProfileFile file in profile.Files){
   if(file.Relative==profile.Anchor||!Accepts(file,hashes[pair.Key]))continue;
   string relative=file.Relative.Replace('/','\\');if(!pair.Key.EndsWith("\\"+relative,StringComparison.OrdinalIgnoreCase))continue;
   string group=pair.Key.Substring(0,pair.Key.Length-relative.Length).TrimEnd('\\');string anchor=Path.Combine(group,profile.Anchor.Replace('/','\\'));
   if(!loaded.ContainsKey(anchor)&&missingAnchors.Add(profile.Id+"|"+group))plan.Messages.Add("[主配置未扫描到] "+profile.Name+"：已识别配套 INI，但同一模组内未扫描到启用的 "+profile.Anchor+"。请确认主文件已放回配套文件所在的模组，并检查完整扩展名、禁用前缀或禁用目录；不要用 .bak / .backup 备份文件代替现用 INI。目标位置："+anchor.Substring(mods.Length+1));
  }
  foreach(var pair in loaded){if(consumed.Contains(pair.Key)||rabbits.Any(x=>x.Key==pair.Key))continue;string hash=hashes[pair.Key];if(catalog.PreserveHashes.Contains(hash)||String.IsNullOrWhiteSpace(pair.Value.Text)||(rabbits.Count==1&&IsRabbitAux(pair.Key,rabbits[0].Key,pair.Value.Text))){plan.Messages.Add("[保留配置，不修改] "+pair.Key.Substring(mods.Length+1));continue;}plan.Unverified++;plan.Messages.Add("[未识别，未修改] "+pair.Key.Substring(mods.Length+1)+"\r\n  配置指纹："+hash+"；不依据槽位数字或修复注释推断是否需要适配。");
   // A family hint is diagnostic only. Filename/sidecar matches never authorise
   // editing an unknown anchor, nor bypass a failed whole-group validation.
   bool genericName=Regex.IsMatch(Path.GetFileName(pair.Key),@"^(?:mod|main|config|settings|ibskip|cutoutmask|draw_image|\d+)\.ini$",RegexOptions.IgnoreCase);
   var family=catalog.Profiles.Where(p=>p.Files.Any(f=>Accepts(f,hash))||(!genericName&&p.Files.Any(f=>f.Relative==p.Anchor&&String.Equals(Path.GetFileName(f.Relative),Path.GetFileName(pair.Key),StringComparison.OrdinalIgnoreCase)))).Select(p=>p.Name).Distinct().ToArray();
   if(family.Length>0)plan.Messages.Add("  [已发现相关规则，整组未通过] "+String.Join(" / ",family)+"。请核对上方整组拒绝原因；若主配置不同，请提供实际启用的 INI、同目录配套 INI 及本报告，不要发送 .bak 或 .backup 代替现用文件。");
   else plan.Messages.Add("  [规则库未覆盖] 当前启用配置没有匹配规则。请提供模组名称、原包或实际启用的 INI 及本报告；保持该文件原样，不代表修复完成。");
  }
  // A target INI still depends on shared material rules. Do not skip dependency
  // validation just because no per-mod configuration changes are needed.
  if(plan.Changes.Count==0&&plan.Recognized==0){plan.Messages.Add("本次没有已验证的待写入修改；未识别项目不等于已修复。未执行已识别模组的共享依赖校验。");return;}
  plan.Messages.Add("[共享依赖检查] 即使模组 INI 已与参考配置一致，仍检查 RabbitFX；配置一致不代表运行环境已适配。");
  if(rabbits.Count==0){plan.Blocked=true;plan.Changes.Clear();plan.Messages.Add("[依赖未满足] 当前专用规则需要兼容的 RabbitFX；未安装时不生成共享猜测规则，也不写入部分配置。");return;}
  var rabbit=rabbits[0];try{string description;string adapted=RabbitAdapter.Adapt(rabbit.Value.Text,out description);bool stable=catalog.StableRabbitHashes.Contains(hashes[rabbit.Key]);bool changes=adapted!=rabbit.Value.Text&&!stable;
   if(changes&&plan.Unverified>0){plan.Blocked=true;plan.Changes.Clear();plan.Messages.Add("[共享依赖保护] 需要修改 RabbitFX，但还有 "+plan.Unverified+" 个未确认配置；为避免连带影响原本正常的模组，本次整批未写入。请提供报告及模组原配置后补充规则。");return;}
   if(changes){foreach(var pair in loaded)if(pair.Key!=rabbit.Key&&Regex.IsMatch(pair.Value.Text,@"(?im)^filter_index\s*=\s*1718\.4\s*(?:;[^\n]*)?$"))throw new InvalidDataException("1718.4 已被其他配置占用："+pair.Key.Substring(mods.Length+1));plan.Changes.Insert(0,new Change{Relative=rabbit.Key.Substring(mods.Length+1),Before=rabbit.Value.Raw,BeforeHash=Engine.Hash(rabbit.Value.Raw),After=rabbit.Value.Encode(adapted),Reason=description+"；所有启用配置已通过本批识别，允许更新共享规则"});plan.Messages.Add("[共享规则待更新] "+description);}
   else plan.Messages.Add("[共享规则保持原样] 现有 RabbitFX 与已验证接口兼容，不重写。");
  }catch(Exception error){plan.Blocked=true;plan.Changes.Clear();plan.Messages.Add("[共享依赖未适配] "+error.Message+"；本次整批未写入。");}
  if(plan.Changes.Count==0&&!plan.Blocked)plan.Messages.Add("本次未写入任何文件；已识别配置及其 RabbitFX 接口检查完成，游戏效果仍需实测；未识别项目保持原样。");
  plan.Messages.Add("只写入完整匹配的配置组。写入完成后仍需检查游戏；不匹配的作者版本、改过的配置和未知模型布局保留原样。");
 }
}
}
