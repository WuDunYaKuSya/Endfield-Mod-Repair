﻿using System;
using System.IO;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
[assembly:AssemblyTitle("终末地模组兼容修复")]
[assembly:AssemblyDescription("EFMI 材质 / 深度通道兼容修复工具")]
[assembly:AssemblyVersion("1.3.1.0")]
namespace EFMIRepair {
static class Program {
 [DllImport("user32.dll")]static extern bool SetProcessDPIAware();
 [STAThread]static int Main(string[] args) {
  if(args.Length>0)return CommandLine(args);
  try{SetProcessDPIAware();Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new RepairForm());return 0;}catch(Exception e){MessageBox.Show(e.Message,"无法启动",MessageBoxButtons.OK,MessageBoxIcon.Error);return 3;}
 }
 static int CommandLine(string[] args) {
  string output=null;for(int i=0;i<args.Length-1;i++)if(args[i]=="--report")output=args[i+1];
  try{if(args.Length<2)throw new ArgumentException("用法：--scan / --apply / --restore EFMI路径 [--report 报告路径]");string report;int code=0;
   if(args[0]=="--restore")report=Engine.Restore(args[1]);else {var plan=Engine.Scan(args[1]);report=plan.Report();if(plan.Blocked)code=2;else {if(plan.Skipped>0||plan.Unverified>0)code=4;if(args[0]=="--apply")report+="\r\n\r\n"+(plan.Skipped>0?"存在未适配项，已停止整批写入；本次未修改 Mods。":Engine.Apply(plan));else if(args[0]!="--scan")throw new ArgumentException("未知命令");}}
   if(output!=null)File.WriteAllText(output,report,new System.Text.UTF8Encoding(false));Console.WriteLine(report);return code;
  }catch(Exception e){if(output!=null)File.WriteAllText(output,"错误："+e.Message,new System.Text.UTF8Encoding(false));Console.Error.WriteLine(e);return 3;}
 }
}
class RepairForm:Form {
 TextBox folder=new TextBox(),log=new TextBox();Button browse=new Button(),scan=new Button(),fix=new Button(),restore=new Button(),export=new Button();Label status=new Label();
 public RepairForm(){
  Text="终末地模组兼容修复 v1.3.1 测试版";ClientSize=new Size(850,670);MinimumSize=new Size(740,600);StartPosition=FormStartPosition.CenterScreen;Font=new Font("Microsoft YaHei UI",10);BackColor=Color.FromArgb(245,247,249);
  var title=new Label{Text="终末地 · 模组批量修复",AutoSize=true,Font=new Font(Font.FontFamily,19,FontStyle.Bold),Location=new Point(24,20)};Controls.Add(title);
  var intro=new Label{Text="扫描整个 Mods；只修改完整匹配的配置组，未知配置保持原样。",AutoSize=true,Location=new Point(27,66)};Controls.Add(intro);
  var hint=new Label{Text="选择 EFMI、Mods 或 XXMI Launcher 文件夹：",AutoSize=true,Location=new Point(27,104)};Controls.Add(hint);
  folder.SetBounds(28,133,665,29);folder.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;Controls.Add(folder);
  browse.Text="选择文件夹";browse.SetBounds(705,131,118,33);browse.Anchor=AnchorStyles.Top|AnchorStyles.Right;browse.Click+=(s,e)=>{using(var d=new FolderBrowserDialog{Description="选择 EFMI、Mods 或 XXMI Launcher 文件夹",ShowNewFolderButton=false})if(d.ShowDialog(this)==DialogResult.OK)folder.Text=d.SelectedPath;};Controls.Add(browse);
  scan.Text="仅扫描";scan.SetBounds(28,180,120,40);scan.Click+=async(s,e)=>await Run("scan");Controls.Add(scan);
  fix.Text="一键备份并修复";fix.SetBounds(161,180,190,40);fix.BackColor=Color.FromArgb(25,98,147);fix.ForeColor=Color.White;fix.FlatStyle=FlatStyle.Flat;fix.Click+=async(s,e)=>await Run("apply");Controls.Add(fix);
  restore.Text="撤销/恢复上次修改";restore.SetBounds(364,180,170,40);restore.Click+=async(s,e)=>await Run("restore");Controls.Add(restore);
  export.Text="导出报告";export.SetBounds(547,180,125,40);export.Click+=(s,e)=>{using(var d=new SaveFileDialog{Filter="文本报告|*.txt",FileName="EFMI修复报告.txt"})if(d.ShowDialog(this)==DialogResult.OK)try{File.WriteAllText(d.FileName,log.Text,new System.Text.UTF8Encoding(false));}catch(Exception ex){MessageBox.Show(this,ex.Message,"报告未保存",MessageBoxButtons.OK,MessageBoxIcon.Error);}};Controls.Add(export);
  log.SetBounds(28,239,795,340);log.Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Both;log.WordWrap=false;log.BackColor=Color.White;log.Text="使用方法：\r\n1. 选择 EFMI 文件夹，先扫描，再备份并修复。\r\n2. 配置写入完成后，进游戏按 F10 检查效果。\r\n3. 异常或闪退后退出游戏，点击撤销/恢复上次修改。\r\n\r\nv1.3.1 测试版：收录本次远端珊瑚海岸旧修复输入。\r\n模组配置一致时仍校验共享依赖；未识别原因分项显示。\r\n已收录 15 组：含两套伊冯、两套诀、珊瑚海岸和陈千语 Salt Line。\r\n未知作者版本和后来改过的配置保留原样，报告会列出指纹。\r\n已与参考目标一致的配置不会重复偏移或叠加补丁。\r\n模型缓冲和骨架着色器也校验指纹；不匹配时整组保留。\r\n\r\nRabbitFX 按接口校验，不以版本号白名单判断。\r\n近景点状黑边先核对反虚化开关，报告会读取实际按键。\r\n需要更新共享 RabbitFX 时，未确认的其他配置会阻止整批写入，\r\n避免连带影响原本正常的模组。\r\n\r\n无法保证所有未知模组或未来版本都兼容。\r\n本程序修复显示兼容问题，不包含卡顿或底层 DLL 优化。\r\n\r\n写入前备份；支持恢复 v1.0 / v1.1 / v1.2 的修改与中断记录。";Controls.Add(log);
  status.SetBounds(28,592,795,24);status.Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;status.Text="就绪 · 无需安装 Python · 无联网功能";Controls.Add(status);
  var footer=new Label{Text="只修改匹配规则的 INI；保留启动设置、游戏文件、模型和贴图。",AutoSize=false,Location=new Point(28,625),Size=new Size(795,25),Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right,ForeColor=Color.DimGray};Controls.Add(footer);
 }
 async Task Run(string mode){if(String.IsNullOrWhiteSpace(folder.Text)){browse.PerformClick();if(String.IsNullOrWhiteSpace(folder.Text))return;}string selected=folder.Text;foreach(Control c in new Control[]{browse,scan,fix,restore,folder,export})c.Enabled=false;status.Text=mode=="restore"?"正在校验并还原…":"正在扫描与校验…";
  try{string completion="";string result=await Task.Run(()=>{if(mode=="restore"){completion="还原完成 · 请查看报告";return Engine.Restore(selected);}var p=Engine.Scan(selected);completion=p.Blocked?"未执行 · 请先处理报告中的冲突":p.Skipped>0?"有未适配项 · 整批修改已停止":mode=="scan"?"扫描完成 · 尚未写入任何修改":"配置已写入 · 游戏兼容性待验证";if(!p.Blocked&&p.Skipped==0&&p.Changes.Count==0&&mode!="scan")completion="没有已验证的待写入修改 · 未识别项目请查看报告";if(mode=="scan"||p.Blocked||p.Skipped>0)return p.Report();return p.Report()+"\r\n\r\n"+Engine.Apply(p);});log.Text=result;status.Text=completion;}
  catch(Exception ex){log.AppendText("\r\n\r\n未完成："+ex.Message);status.Text="未完成 · 请查看原因，未匹配的文件不会强制修改";}
  finally{foreach(Control c in new Control[]{browse,scan,fix,restore,folder,export})c.Enabled=true;}
 }
}
}
