﻿$ErrorActionPreference = 'Stop'
$sourceDir = $PSScriptRoot
$outputDir = Split-Path -Parent $sourceDir
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (-not (Test-Path -LiteralPath $compiler)) { throw '.NET Framework C# compiler not found.' }
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll (('/win32manifest:') + (Join-Path $sourceDir 'app.manifest')) (('/resource:') + (Join-Path $sourceDir 'CurrentMaterial.pattern') + ',EFMIRepair.CurrentMaterial.pattern') (('/out:') + (Join-Path $outputDir 'EndfieldModRepair.exe')) (Join-Path $sourceDir 'Engine.cs') (Join-Path $sourceDir 'RabbitAdapter.cs') (Join-Path $sourceDir 'Program.cs') (Join-Path $sourceDir 'Profiles.cs') (('/resource:') + (Join-Path $sourceDir 'Profiles.xml') + ',EFMIRepair.Profiles.xml')
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
Write-Output (Join-Path $outputDir 'EndfieldModRepair.exe')
