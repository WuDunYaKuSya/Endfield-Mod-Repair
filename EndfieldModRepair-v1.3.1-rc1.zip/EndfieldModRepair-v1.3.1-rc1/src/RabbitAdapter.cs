using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;

namespace EFMIRepair {
// Recognise the resource API and shader template, rather than trusting a version comment.
// Only the main-material rule is migrated. Shadow rules, keys, FX and cleanup remain local.
static class RabbitAdapter {
 const string Main = "ShaderRegexMain";
 const string Current = "ShaderRegexMain202610";
 static readonly Regex Sections = new Regex(@"(?ms)^\[([^\]\r\n]+)\][^\n]*\n(.*?)(?=^\[|\z)");
 static Match Get(string text, string name) {
  var matches = Sections.Matches(text).Cast<Match>().Where(m => m.Groups[1].Value.Equals(name, StringComparison.OrdinalIgnoreCase)).ToArray();
  if (matches.Length != 1) throw new InvalidOperationException("RabbitFX 配置节缺失或重复：" + name);
  return matches[0];
 }
 static bool Has(string text, string value) { return text.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0; }
 static void Require(bool test, string message) { if (!test) throw new InvalidOperationException(message); }
 static bool Number(string body, string name, string value) {
  return Regex.IsMatch(body, @"(?im)^[ \t]*" + Regex.Escape(name) + @"[ \t]*=[ \t]*" + Regex.Escape(value) + @"[ \t]*(?:;[^\n]*)?$");
 }
 const string DisabledPrefix = "(?!)";
 static string CurrentPattern() {
  using (var stream = typeof(RabbitAdapter).Assembly.GetManifestResourceStream("EFMIRepair.CurrentMaterial.pattern")) {
   Require(stream != null, "程序缺少当前游戏材质规则，请完整解压或重新构建");
   using (var reader = new StreamReader(stream)) return reader.ReadToEnd().Trim();
  }
 }
 static string ActiveLines(string body) { return String.Join("\n", body.Split('\n').Where(l => !l.TrimStart().StartsWith(";"))); }
 static void CaptureContract(string text, string pattern) {
  string replacement = ActiveLines(Get(text, Main + ".Pattern.Replace").Groups[2].Value);
  var available = new HashSet<string>(Regex.Matches(pattern, @"\(\?<([A-Za-z_]\w*)>").Cast<Match>().Select(m => m.Groups[1].Value), StringComparer.Ordinal);
  Match temps = Regex.Match(Get(text, Main).Groups[2].Value, @"(?im)^[ \t]*temps[ \t]*=[ \t]*([^;\n]+)");
  foreach (string temp in Regex.Split(temps.Groups[1].Value.Trim(), @"\s+")) { Require(!available.Contains(temp), "RabbitFX 临时寄存器名称与兼容规则冲突：" + temp); available.Add(temp); }
  foreach (Match reference in Regex.Matches(replacement, @"\$\{([A-Za-z_]\w*)"))
   Require(available.Contains(reference.Groups[1].Value), "此 RabbitFX 特效需要额外的着色器数据，当前兼容层无法提供：" + reference.Groups[1].Value);
  Require(!Regex.IsMatch(replacement, @"(?<!\\)\$(?:\d|\{\d)"), "此 RabbitFX 使用位置编号捕获，无法保证跨模板迁移安全");
  // Every consumed instruction range must be handled by the original FX template.
  foreach (string group in new[] { "header", "func", "head", "diffuse", "lightmapsplit", "lightmap", "split", "normalmap", "rainmap", "normalmap2", "body", "output", "elseoutput" })
   Require(Regex.IsMatch(replacement, @"\$\{" + group + @"(?:\}|:)"), "此 RabbitFX 的指令保留接口不同：" + group);
 }
 static string Condition(string body) {
  string old = @"\([ \t]*ps[ \t]*==[ \t]*\$RabbitFXMain[ \t]*\|\|[ \t]*ps[ \t]*==[ \t]*\$RabbitFXShadow[ \t]*\)";
  string updated = @"\([ \t]*ps[ \t]*==[ \t]*\$RabbitFXMain[ \t]*\|\|[ \t]*ps[ \t]*==[ \t]*1718\.4[ \t]*\|\|[ \t]*ps[ \t]*==[ \t]*\$RabbitFXShadow[ \t]*\)";
  var regex = new Regex(old, RegexOptions.IgnoreCase);
  int oldCount = regex.Matches(body).Count, newCount = Regex.Matches(body, updated, RegexOptions.IgnoreCase).Count;
  Require(oldCount + newCount == 1, "RabbitFX 贴图/特效提交条件无法安全迁移");
  return oldCount == 1 ? regex.Replace(body, "(ps == $RabbitFXMain || ps == 1718.4 || ps == $RabbitFXShadow)") : body;
 }
 static void Interface(string text) {
  string constants = String.Join("\n", Sections.Matches(text).Cast<Match>().Where(m => m.Groups[1].Value.Equals("Constants", StringComparison.OrdinalIgnoreCase)).Select(m => m.Groups[2].Value));
  Require(Number(constants, @"global $RabbitFXMain", "1718.1") && Number(constants, @"global $RabbitFXShadow", "1718.2"), "RabbitFX 通道编号或常量接口不同，不能使用本次规则");
  string body = Get(text, "CommandListSetTextures").Groups[2].Value;
  string[] resources = { "Diffuse", "Lightmap", "Normalmap", "DiscardMap", "Rainmap" };
  for (int i = 0; i < resources.Length; i++) {
   Get(text, "Resource" + resources[i]);
   Require(Regex.IsMatch(body, @"(?im)^[ \t]*ps-t" + (70+i) + @"[ \t]*=[ \t]*ref[ \t]+Resource" + resources[i] + @"[ \t]*(?:;[^\n]*)?$"), "RabbitFX 资源绑定接口不同：" + resources[i]);
  }
  Condition(body);
  Condition(Get(text, "CommandListRun").Groups[2].Value);
  Require(Number(Get(text, Main).Groups[2].Value, "filter_index", "1718.1"), "RabbitFX 主材质编号不同");
  string declarations = Get(text, Main + ".InsertDeclarations").Groups[2].Value;
  Require(Regex.IsMatch(declarations, @"(?im)^dcl_resource_texture1d[^\n]+\bt120[ \t]*$"), "RabbitFX 参数纹理接口不同");
  foreach (int slot in new[] { 60,61,70,71,72,74 }) Require(Regex.IsMatch(declarations, @"(?im)^dcl_resource_texture2d[^\n]+\bt" + slot + @"[ \t]*$"), "RabbitFX 主材质资源声明不完整");
  string replacement = Get(text, Main + ".Pattern.Replace").Groups[2].Value;
  Require(replacement.Contains("${header}") && replacement.Contains("${body}"), "RabbitFX 主材质替换模板不兼容");
 }
 static string MainBlock(string text) {
  Match start = Get(text, Main);
  int end = text.Length;
  foreach (Match m in Sections.Matches(text)) {
   if (m.Index <= start.Index) continue;
   if (m.Groups[1].Value.StartsWith(Main + ".", StringComparison.OrdinalIgnoreCase)) continue;
   end = m.Index; break;
  }
  string block = text.Substring(start.Index, end - start.Index);
  foreach (string suffix in new[] { "", ".Pattern", ".InsertDeclarations", ".Pattern.Replace" }) Get(block, Main + suffix);
  Require(Sections.Matches(block).Count == 4, "RabbitFX 使用额外的主材质规则阶段，需单独确认其接口");
  return block;
 }
 public static string Adapt(string text, out string description) {
  string version = Regex.Match(text, @"(?im)^[ \t]*;[^\n]*\bVersion[ \t]+([^\n]+)").Groups[1].Value.Trim();
  if (version.Length == 0) version = "版本未标注";
  description = "RabbitFX " + version;
  Interface(text);
  string oldPattern = Get(text, Main + ".Pattern").Groups[2].Value.Trim();
  string pattern = CurrentPattern();
  CaptureContract(text, pattern);
  bool exists = Sections.Matches(text).Cast<Match>().Any(m => m.Groups[1].Value.Equals(Current, StringComparison.OrdinalIgnoreCase));
  bool marked = Has(text, "; EFMI Mod Repair v1.2 - RabbitFX current-game adapter");
  Require(!oldPattern.StartsWith(DisabledPrefix, StringComparison.Ordinal) || marked, "主材质规则已被其他配置停用，未自动重新启用");
  string changed = Sections.Replace(text, m => {
   string name = m.Groups[1].Value;
   if (name.Equals(Main + ".Pattern", StringComparison.OrdinalIgnoreCase) && !oldPattern.StartsWith(DisabledPrefix, StringComparison.Ordinal))
    return m.Value.Substring(0, m.Groups[2].Index - m.Index) + m.Groups[2].Value.Replace(oldPattern, DisabledPrefix + "(?:" + oldPattern + ")");
   if (!name.Equals("CommandListSetTextures", StringComparison.OrdinalIgnoreCase) && !name.Equals("CommandListRun", StringComparison.OrdinalIgnoreCase)) return m.Value;
   string body = m.Groups[2].Value;
   return m.Value.Substring(0, m.Groups[2].Index - m.Index) + Condition(body);
  });
  if (exists) {
   string currentPattern = Get(text, Current + ".Pattern").Groups[2].Value.Trim();
   // v1.1 generated the same captures with a flexible optional CB7 for 2.7.
   Require(currentPattern.Replace(@"CB7)?(?(cb7)\[\d{3}\]", @"CB7)?(?(cb7)\[160\]") == pattern && Number(Get(text, Current).Groups[2].Value, "filter_index", "1718.4"), "现有 RabbitFX 兼容规则与当前游戏规则不一致，请先检查其他补丁");
   string expectedRoot = Regex.Replace(Get(text, Main).Groups[2].Value, @"(?im)^([ \t]*filter_index[ \t]*=[ \t]*)1718\.1([ \t]*(?:;[^\n]*)?)$", "${1}1718.4${2}");
   Require(Get(text, Current).Groups[2].Value.Trim() == expectedRoot.Trim(), "现有 RabbitFX 兼容规则的清理或触发逻辑已被修改");
   Require(Get(text, Current + ".InsertDeclarations").Groups[2].Value.Trim() == Get(text, Main + ".InsertDeclarations").Groups[2].Value.Trim(), "现有 RabbitFX 兼容规则的资源声明已被修改");
   // Validate the preserved version-specific cleanup/template too, not only the pattern.
   string currentTemplate = Get(text, Current + ".Pattern.Replace").Groups[2].Value.Trim();
   Require(currentTemplate == Get(text, Main + ".Pattern.Replace").Groups[2].Value.Trim(), "现有 RabbitFX 兼容规则的特效模板已被修改");
   description += "；现有适配已校验；统一当前游戏规则";
   return !marked ? changed.Insert(Get(changed, Current).Index, "; EFMI Mod Repair v1.2 - RabbitFX current-game adapter\n") : changed;
  }
  Require(!Has(text, "[" + Current + "."), "RabbitFX 兼容规则不完整，未自动覆盖");
  string block = MainBlock(text);
  block = Sections.Replace(block, m => {
   string name = m.Groups[1].Value;
   string body = m.Groups[2].Value;
   if (name.Equals(Main + ".Pattern", StringComparison.OrdinalIgnoreCase)) body = body.Replace(oldPattern, pattern);
   if (name.Equals(Main, StringComparison.OrdinalIgnoreCase)) body = Regex.Replace(body, @"(?im)^([ \t]*filter_index[ \t]*=[ \t]*)1718\.1([ \t]*(?:;[^\n]*)?)$", "${1}1718.4${2}");
   return "[" + Current + name.Substring(Main.Length) + "]\n" + body;
  });
  description += "；统一当前游戏规则，不依赖旧版正则写法";
  description += "；保留原版按键、特效与清理规则";
  return changed + "\n; EFMI Mod Repair v1.2 - RabbitFX current-game adapter\n" + block;
 }
}
}
