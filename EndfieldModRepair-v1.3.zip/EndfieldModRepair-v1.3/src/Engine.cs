﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Xml.Serialization;

namespace EFMIRepair {
public class Change { public string Relative, Reason, BeforeHash; public byte[] Before, After; }
public class Plan {
 public string Root; public List<Change> Changes = new List<Change>();public Dictionary<string,string> AssetGuards=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);public HashSet<string> ApprovedMissing=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
 public List<string> Messages = new List<string>(); public int Scanned, Covered, Skipped, Recognized, Unverified; public bool CheckInventory; public Dictionary<string,string> Guards=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase); public bool Blocked;
 public string Report() { return "EFMI 模组兼容修复 v1.3\r\n目标："+Root+"\r\n扫描 "+Scanned+" 个 INI；识别 "+Recognized+" 个配置组；待写入 "+Changes.Count+" 个文件；未识别保留 "+Unverified+" 个配置；读取失败 "+Skipped+" 个。\r\n\r\n"+String.Join("\r\n",Messages)+"\r\n\r\n"+String.Join("\r\n",Changes.Select(c=>"[待写入] "+c.Relative+"\r\n  "+c.Reason)); }
}
public class Entry { public string Relative, BeforeHash, AfterHash; public bool Created; }
public class BackupManifest { public string Root, State, Version; public long CreatedUtcTicks; public List<Entry> Files=new List<Entry>(); }
class Ini {
 public byte[] Raw; public string Text; public Encoding Encoding; public byte[] Bom; public string Eol;
 string[] originalLines,originalEols;bool mixedEols;
 public Ini(byte[] raw) {
  Raw=raw; Bom=new byte[0]; int offset=0;
  if(raw.Length>=3 && raw[0]==239 && raw[1]==187 && raw[2]==191) { Encoding=new UTF8Encoding(false,true); offset=3; }
  else if(raw.Length>=2 && raw[0]==255 && raw[1]==254) { Encoding=new UnicodeEncoding(false,false,true); offset=2; }
  else if(raw.Length>=2 && raw[0]==254 && raw[1]==255) { Encoding=new UnicodeEncoding(true,false,true); offset=2; }
  else { Encoding=new UTF8Encoding(false,true); try { Encoding.GetString(raw); } catch(DecoderFallbackException) { Encoding=System.Text.Encoding.GetEncoding(54936,EncoderFallback.ExceptionFallback,DecoderFallback.ExceptionFallback); } }
  Bom=raw.Take(offset).ToArray(); string text=Encoding.GetString(raw,offset,raw.Length-offset);
  Eol=text.Contains("\r\r\n")?"\r\r\n":text.Contains("\r\n")?"\r\n":text.Contains("\n")?"\n":text.Contains("\r")?"\r":"\n";
  var endings=Regex.Matches(text,@"\r\r\n|\r\n|\r|\n").Cast<Match>().Select(m=>m.Value).ToArray();
  originalEols=endings;mixedEols=endings.Distinct().Count()>1;
  Text=Regex.Replace(text,@"\r\r\n|\r\n|\r|\n","\n");originalLines=Text.Split('\n');
  if(!Bom.Concat(Encoding.GetBytes(text)).SequenceEqual(raw)) throw new InvalidDataException("配置编码无法无损保留");
 }
 // Hirschberg line alignment uses linear memory. Unchanged lines retain their own
 // original terminators even when a mod mixes CRLF, LF, CR or CRCRLF.
 static int[] Scores(string[] a,int ai,int an,string[] b,int bi,int bn,bool reverse) {
  var row=new int[bn+1];
  for(int i=0;i<an;i++){int diagonal=0;for(int j=1;j<=bn;j++){int previous=row[j];if(a[ai+(reverse?an-1-i:i)]==b[bi+(reverse?bn-j:j-1)])row[j]=diagonal+1;else row[j]=Math.Max(row[j],row[j-1]);diagonal=previous;}}
  return row;
 }
 static void Align(string[] a,int ai,int an,string[] b,int bi,int bn,int[] map) {
  while(an>0&&bn>0&&a[ai]==b[bi]){map[bi]=ai;ai++;bi++;an--;bn--;}
  while(an>0&&bn>0&&a[ai+an-1]==b[bi+bn-1]){map[bi+bn-1]=ai+an-1;an--;bn--;}
  if(an==0||bn==0)return;
  if(an==1){for(int j=0;j<bn;j++)if(a[ai]==b[bi+j]){map[bi+j]=ai;break;}return;}
  int half=an/2,split=0,best=-1;int[] left=Scores(a,ai,half,b,bi,bn,false),right=Scores(a,ai+half,an-half,b,bi,bn,true);
  for(int j=0;j<=bn;j++)if(left[j]+right[bn-j]>best){best=left[j]+right[bn-j];split=j;}
  Align(a,ai,half,b,bi,split,map);Align(a,ai+half,an-half,b,bi+split,bn-split,map);
 }
 public byte[] Encode(string text) {
  if(text==Text)return Raw;
  if(!mixedEols)return Bom.Concat(Encoding.GetBytes(Eol=="\n"?text:text.Replace("\n",Eol))).ToArray();
  string[] lines=text.Split('\n');var map=Enumerable.Repeat(-1,lines.Length).ToArray();Align(originalLines,0,originalLines.Length,lines,0,lines.Length,map);var result=new StringBuilder();
  for(int i=0;i<lines.Length;i++){result.Append(lines[i]);if(i<lines.Length-1)result.Append(map[i]>=0&&map[i]<originalEols.Length?originalEols[map[i]]:Eol);}
  return Bom.Concat(Encoding.GetBytes(result.ToString())).ToArray();
 }
}
public static class Engine {
 public const string Marker="; EFMI Mod Repair v1.0 - 2026-10 compatibility";
 public static string Hash(byte[] data) { using(var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(data)).Replace("-","").ToLowerInvariant(); }
 public static string RootOf(string input) {
  string path=Path.GetFullPath(input.Trim().Trim('"')).TrimEnd(Path.DirectorySeparatorChar);
  if(String.Equals(Path.GetFileName(path),"Mods",StringComparison.OrdinalIgnoreCase))path=Directory.GetParent(path).FullName;
  if(!File.Exists(Path.Combine(path,"d3dx.ini")) && Directory.Exists(Path.Combine(path,"EFMI")))path=Path.Combine(path,"EFMI");
  if(!File.Exists(Path.Combine(path,"d3dx.ini")) || !Directory.Exists(Path.Combine(path,"Mods")) || !File.Exists(Path.Combine(path,"Core","EFMI","API.ini")))throw new InvalidDataException("请选择有效的 EFMI 文件夹，或其 Mods 文件夹 / XXMI Launcher 文件夹。");
  RejectLink(path); RejectLink(Path.Combine(path,"Mods"));return path;
 }
 static void RejectLink(string path) { if((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("为避免修改到其他目录，请选择实际文件夹，不使用目录链接："+path); }
 static bool Disabled(string name) { return name.StartsWith("disabled",StringComparison.OrdinalIgnoreCase)||name.StartsWith(".")||name.StartsWith("backup",StringComparison.OrdinalIgnoreCase)||name.StartsWith("备份")||name.StartsWith("_ModRepairBackups",StringComparison.OrdinalIgnoreCase); }
 static void Walk(string directory,List<string> result,List<string> messages) {
  foreach(string p in Directory.GetFiles(directory,"*.ini")) { if(Disabled(Path.GetFileName(p)))continue; if((File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0) { messages.Add("[跳过链接] "+p);continue; } result.Add(p); }
  foreach(string d in Directory.GetDirectories(directory)) { if(Disabled(Path.GetFileName(d)))continue; if((File.GetAttributes(d)&FileAttributes.ReparsePoint)!=0){messages.Add("[跳过链接] "+d);continue;} Walk(d,result,messages); }
 }
 static string Within(string root,string relative) {
  if(String.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative))throw new InvalidDataException("备份包含非法路径");
  string prefix=Path.GetFullPath(root).TrimEnd('\\')+"\\";string full=Path.GetFullPath(Path.Combine(root,relative));
  if(!full.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("路径超出目标目录");
  for(string p=full; p!=null && p.StartsWith(prefix,StringComparison.OrdinalIgnoreCase);p=Path.GetDirectoryName(p))if(File.Exists(p)||Directory.Exists(p))RejectLink(p);
  return full;
 }
 internal static string CheckedPath(string root,string relative){return Within(root,relative);}
 public static Plan Scan(string input) {
  var plan=new Plan();plan.Root=RootOf(input);string unfinished=FindUnfinished(plan.Root);if(unfinished!=null){plan.Blocked=true;plan.Messages.Add("[恢复优先] 检测到未完成的修改，先点击撤销/恢复上次修改："+unfinished);return plan;}string mods=Path.Combine(plan.Root,"Mods");var files=new List<string>();Walk(mods,files,plan.Messages);files.Sort(StringComparer.OrdinalIgnoreCase);plan.Scanned=files.Count;if(plan.Messages.Any(x=>x.Contains("[跳过链接]")))plan.Skipped++;
  var loaded=new Dictionary<string,Ini>(StringComparer.OrdinalIgnoreCase);foreach(string path in files)try{var ini=new Ini(File.ReadAllBytes(path));loaded.Add(path,ini);plan.Guards.Add(path.Substring(mods.Length+1),Hash(ini.Raw));}catch(Exception error){plan.Skipped++;plan.Messages.Add("[读取失败，不写入] "+path+"："+error.Message);}
  plan.CheckInventory=true;ProfilePlanner.Build(plan,loaded,mods);if(plan.Skipped>0){plan.Blocked=true;plan.Changes.Clear();plan.Messages.Add("[整批停止] 存在无法读取或目录链接，未生成写入。");}return plan;
 }
 static void Atomic(string path,byte[] data) {
  string temp=path+".efmirepair-"+Guid.NewGuid().ToString("N")+".tmp";
  try{using(var fs=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){fs.Write(data,0,data.Length);fs.Flush(true);}if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);}
  finally{if(File.Exists(temp))File.Delete(temp);}
 }
 static void SaveManifest(string dir,BackupManifest manifest) {using(var stream=new MemoryStream()){new XmlSerializer(typeof(BackupManifest)).Serialize(stream,manifest);Atomic(Path.Combine(dir,"manifest.xml"),stream.ToArray());}}
 static FileStream OperationLock(string root) {
  try{return new FileStream(Path.Combine(root,".efmi-repair-operation.lock"),FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None,4096,FileOptions.DeleteOnClose);}
  catch(IOException e){throw new IOException("此 EFMI 目录已有修复/撤销操作，或无法取得写入锁。请关闭另一个工具窗口后重试。",e);}
 }
 static IEnumerable<string> BackupOrder(string store){var dates=new List<KeyValuePair<string,long>>();foreach(string dir in Directory.GetDirectories(store)){RejectLink(dir);string file=Path.Combine(dir,"manifest.xml");long ticks=Directory.GetCreationTimeUtc(dir).Ticks;if(File.Exists(file)){BackupManifest m=LoadManifest(file);if(m.CreatedUtcTicks>0)ticks=m.CreatedUtcTicks;}dates.Add(new KeyValuePair<string,long>(dir,ticks));}return dates.OrderByDescending(x=>x.Value).ThenByDescending(x=>x.Key,StringComparer.OrdinalIgnoreCase).Select(x=>x.Key);}
 static bool Unfinished(string state){return state=="prepared"||state=="partial"||state=="restoring"||state=="partial_restore";}
 static BackupManifest LoadManifest(string path){RejectLink(path);using(var fs=File.OpenRead(path))return (BackupManifest)new XmlSerializer(typeof(BackupManifest)).Deserialize(fs);}
 static string FindUnfinished(string root) {
  string store=Path.Combine(root,"_ModRepairBackups");if(!Directory.Exists(store))return null;RejectLink(store);
  foreach(string dir in BackupOrder(store)){RejectLink(dir);string file=Path.Combine(dir,"manifest.xml");if(!File.Exists(file))continue;BackupManifest m=LoadManifest(file);if(Unfinished(m.State))return dir;}
  return null;
 }
 static void ProbeWrite(string path){using(var fs=new FileStream(path,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite|FileShare.Delete)){}}
 static string CurrentHash(string path){return File.Exists(path)?Hash(File.ReadAllBytes(path)):null;}
 static void ValidateManifest(string root,string backup,BackupManifest m) {
  if(m==null||String.IsNullOrWhiteSpace(m.Root)||!String.Equals(Path.GetFullPath(m.Root).TrimEnd('\\'),root.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase))throw new IOException("备份属于另一个 EFMI 目录");
  if(m.Files==null)throw new InvalidDataException("备份文件列表缺失");var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  foreach(Entry e in m.Files){if(e==null)throw new InvalidDataException("备份包含空记录");string path=Within(Path.Combine(root,"Mods"),e.Relative);if(!seen.Add(path))throw new InvalidDataException("备份包含重复目标："+e.Relative);
   if(String.IsNullOrEmpty(e.AfterHash)||!Regex.IsMatch(e.AfterHash,@"\A[0-9a-f]{64}\z"))throw new InvalidDataException("备份的修复后校验值无效："+e.Relative);
   if(e.Created){if(e.BeforeHash!=null)throw new InvalidDataException("新增文件的备份记录不一致："+e.Relative);}
   else{string original=Within(Path.Combine(backup,"originals"),e.Relative);if(!File.Exists(original)||CurrentHash(original)!=e.BeforeHash)throw new IOException("原始备份校验失败："+e.Relative);}
  }
 }
 // Accept both pre-repair and post-repair bytes. A killed process or failed
 // rollback can leave a mixture; only known tool-generated bytes are undone.
 static int RecoverRecord(string root,string backup,BackupManifest m) {
  ValidateManifest(root,backup,m);string mods=Path.Combine(root,"Mods");var todo=new List<Entry>();
  foreach(Entry e in m.Files){string path=Within(mods,e.Relative);string actual=CurrentHash(path);if(actual==e.BeforeHash)continue;if(actual!=e.AfterHash)throw new IOException("文件已被后续修改，本次未覆盖："+e.Relative+"\r\n原始备份："+backup+"\r\n请保留报告后使用原包核对，不要手动删除所有带修复标记的行。");todo.Add(e);}
  // Catch existing locks/read-only files before changing any other file.
  foreach(Entry e in todo)ProbeWrite(Within(mods,e.Relative));
  m.State="restoring";SaveManifest(backup,m);int restored=0;
  try{foreach(Entry e in todo){string path=Within(mods,e.Relative);if(CurrentHash(path)!=e.AfterHash)throw new IOException("撤销前文件发生变化："+e.Relative);if(e.Created)File.Delete(path);else Atomic(path,File.ReadAllBytes(Within(Path.Combine(backup,"originals"),e.Relative)));if(CurrentHash(path)!=e.BeforeHash)throw new IOException("撤销写入校验失败："+e.Relative);restored++;}
   m.State="restored";SaveManifest(backup,m);return restored;
  }catch(Exception error){m.State="partial_restore";try{SaveManifest(backup,m);}catch(Exception journal){throw new IOException("撤销未完成，且状态记录写入失败。请保留备份并再次点击撤销："+backup+"\r\n"+error.Message+"\r\n"+journal.Message,error);}throw new IOException("撤销未完成，已恢复的文件保持原样，没有重新写回补丁。解除文件占用后再次点击撤销即可续做。\r\n备份："+backup+"\r\n"+error.Message,error);}
 }
 public static string Apply(Plan plan) {
  if(plan.Blocked)throw new InvalidOperationException("请先处理扫描报告中的冲突");
  if(plan.Skipped>0)throw new InvalidOperationException("存在无法适配或无法读取的配置，已停止整批写入；本次未修改 Mods。请先处理扫描报告，避免只写入部分依赖规则。");
  if(plan.Changes.Count==0)return "没有需要修改的文件。游戏显示是否正常仍需实测。";
  string root=RootOf(plan.Root);using(var operation=OperationLock(root))return ApplyLocked(plan,root);
 }
 static string ApplyLocked(Plan plan,string root) {
  string pending=FindUnfinished(root);if(pending!=null)throw new IOException("发现未完成的修复/撤销，请先点击“撤销/恢复上次修改”，不要继续叠加修复。\r\n备份："+pending);
  string mods=Path.Combine(root,"Mods");if(plan.CheckInventory){var current=new List<string>();Walk(mods,current,new List<string>());if(current.Count!=plan.Guards.Count||current.Any(path=>!plan.Guards.ContainsKey(path.Substring(mods.Length+1))||CurrentHash(path)!=plan.Guards[path.Substring(mods.Length+1)]))throw new IOException("扫描后有配置新增、删除或被修改，请重新扫描；本次未写入。");foreach(var asset in plan.AssetGuards){string full=CheckedPath(mods,asset.Key);if(!File.Exists(full)||CurrentHash(full)!=asset.Value)throw new IOException("扫描后模型或骨架着色器发生变化，请重新扫描；本次未写入："+asset.Key);}foreach(Change change in plan.Changes)ProfilePlanner.ValidateFile(mods,Within(mods,change.Relative),new Ini(change.After).Text,plan.ApprovedMissing);}var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  foreach(Change c in plan.Changes){string path=Within(mods,c.Relative);if(!seen.Add(path))throw new InvalidDataException("修复计划包含重复文件");if(c.Before==null?File.Exists(path):CurrentHash(path)!=c.BeforeHash)throw new IOException("扫描后文件发生了变化，请重新扫描："+c.Relative);if(c.After==null)throw new InvalidDataException("修复数据缺失");if(c.Before!=null)ProbeWrite(path);}
  string store=Path.Combine(root,"_ModRepairBackups");if(Directory.Exists(store))RejectLink(store);string backup=Path.Combine(store,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8));Directory.CreateDirectory(backup);RejectLink(store);
  var m=new BackupManifest{Root=root,Version="1.3",State="prepared",CreatedUtcTicks=DateTime.UtcNow.Ticks};
  foreach(Change c in plan.Changes){m.Files.Add(new Entry{Relative=c.Relative,BeforeHash=c.BeforeHash,AfterHash=Hash(c.After),Created=c.Before==null});if(c.Before!=null){string path=Within(Path.Combine(backup,"originals"),c.Relative);Directory.CreateDirectory(Path.GetDirectoryName(path));Atomic(path,c.Before);if(CurrentHash(path)!=c.BeforeHash)throw new IOException("原始备份校验失败，本次未写入 Mods："+c.Relative);}}
  Atomic(Path.Combine(backup,"report.txt"),new UTF8Encoding(false).GetBytes(plan.Report()));SaveManifest(backup,m);
  try{foreach(Change c in plan.Changes){string path=Within(mods,c.Relative);if(CurrentHash(path)!=c.BeforeHash)throw new IOException("写入前文件已变化："+c.Relative);Atomic(path,c.After);if(CurrentHash(path)!=Hash(c.After))throw new IOException("写入校验失败："+c.Relative);}m.State="applied";SaveManifest(backup,m);}
  catch(Exception error){bool recovered=false;string recoveryError="";try{RecoverRecord(root,backup,m);m.State="rolled_back";SaveManifest(backup,m);recovered=true;}catch(Exception recovery){recoveryError="\r\n恢复原因："+recovery.Message;m.State="partial";try{SaveManifest(backup,m);}catch{}}
   throw new IOException("配置写入未完成，"+(recovered?"本次修改已撤销并校验。":"请解除占用后点击“撤销/恢复上次修改”，恢复完成前不要启动游戏或继续修复。")+"\r\n备份："+backup+"\r\n"+error.Message+recoveryError,error);}
  return "配置写入完成（"+plan.Changes.Count+" 个文件），尚未验证游戏兼容性。\r\n备份："+backup+"\r\n若进游戏异常或闪退，请退出游戏，点击“撤销/恢复上次修改”。不要再次修复或手动删除补丁片段。\r\n撤销会按校验值恢复原始 INI，并删除本批由工具新建的规则文件。";
 }
 public static string Restore(string input) {
  string root=RootOf(input);using(var operation=OperationLock(root))return RestoreLocked(root);
 }
 static string RestoreLocked(string root) {
  string store=Path.Combine(root,"_ModRepairBackups");if(!Directory.Exists(store))return "此目录没有本工具创建的备份；无法依据标记安全还原，请使用模组原包。";RejectLink(store);string selected=null;BackupManifest selectedManifest=null;
  // A newer applied transaction may depend on an older unfinished one. Undo
  // in reverse chronological order rather than jumping over newer records.
  foreach(string dir in BackupOrder(store)){RejectLink(dir);string file=Path.Combine(dir,"manifest.xml");if(!File.Exists(file))continue;BackupManifest candidate=LoadManifest(file);if(candidate.State=="applied"||Unfinished(candidate.State)){selected=dir;selectedManifest=candidate;break;}}
  if(selected==null)return "没有尚未撤销的修复记录。";
  int changed=RecoverRecord(root,selected,selectedManifest);
  return "已撤销/恢复最近一批修改：本次恢复 "+changed+" 个文件，其余文件已是原始状态。新增规则已按记录清理，原始 INI 校验通过。\r\n备份保留："+selected+"\r\n多次执行过修复时，可继续点击撤销，按从新到旧的顺序逐批恢复。\r\n请重新启动游戏验证；若仍异常，请保留报告与备份进一步排查。";
 }
}
}
